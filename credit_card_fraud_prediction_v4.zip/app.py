import streamlit as st
import pandas as pd
import joblib
from datetime import datetime

st.set_page_config(page_title="Credit Card Fraud Financial Loss", page_icon="💳", layout="wide")

st.markdown("""<style>
.block-container{padding-top:1.8rem;padding-bottom:2rem}.hero{padding:2.3rem 2.5rem;border-radius:22px;background:linear-gradient(135deg,#111827,#263449);color:white;margin-bottom:1.5rem}.hero h1{margin:0 0 .55rem;font-size:2.45rem}.hero p{margin:0;color:#d1d5db;font-size:1.06rem}.card{padding:1.25rem 1.35rem;border:1px solid rgba(128,128,128,.22);border-radius:16px;background:rgba(128,128,128,.045);min-height:120px}.result-card{padding:2rem;border-radius:20px;border:1px solid rgba(128,128,128,.25);text-align:center;margin-top:1rem;background:rgba(128,128,128,.04)}.result-card .amount{font-size:2.9rem;font-weight:800;margin:.35rem 0}.small-note{font-size:.9rem;opacity:.75}.badge{display:inline-block;padding:.35rem .7rem;border-radius:999px;background:rgba(128,128,128,.12);font-size:.85rem;margin-right:.35rem}</style>""",unsafe_allow_html=True)

@st.cache_resource
def load_bundle(): return joblib.load("fraud_financial_loss_model.pkl")
@st.cache_data
def load_locations(): return pd.read_csv("locations.csv")

bundle=load_bundle(); model=bundle["model"]; AMT_MIN=bundle["amount_min"]; AMT_MAX=bundle["amount_max"]; RESULTS=bundle["results"]
locations=load_locations()
STATE_NAMES={"AL":"Alabama","AK":"Alaska","AZ":"Arizona","AR":"Arkansas","CA":"California","CO":"Colorado","CT":"Connecticut","DE":"Delaware","FL":"Florida","GA":"Georgia","HI":"Hawaii","ID":"Idaho","IL":"Illinois","IN":"Indiana","IA":"Iowa","KS":"Kansas","KY":"Kentucky","LA":"Louisiana","ME":"Maine","MD":"Maryland","MA":"Massachusetts","MI":"Michigan","MN":"Minnesota","MS":"Mississippi","MO":"Missouri","MT":"Montana","NE":"Nebraska","NV":"Nevada","NH":"New Hampshire","NJ":"New Jersey","NM":"New Mexico","NY":"New York","NC":"North Carolina","ND":"North Dakota","OH":"Ohio","OK":"Oklahoma","OR":"Oregon","PA":"Pennsylvania","RI":"Rhode Island","SC":"South Carolina","SD":"South Dakota","TN":"Tennessee","TX":"Texas","UT":"Utah","VT":"Vermont","VA":"Virginia","WA":"Washington","WV":"West Virginia","WI":"Wisconsin","WY":"Wyoming","DC":"District of Columbia"}
states=sorted(locations.state.unique().tolist(),key=lambda c:STATE_NAMES.get(c,c)); display_names=[STATE_NAMES.get(c,c) for c in states]; display_to_code={STATE_NAMES.get(c,c):c for c in states}
categories=sorted(locations.category.dropna().unique().tolist()) if "category" in locations else ["entertainment","food_dining","gas_transport","grocery_net","grocery_pos","health_fitness","home","kids_pets","misc_net","misc_pos","personal_care","shopping_net","shopping_pos","travel"]

with st.sidebar:
 st.markdown("## 💳 Loss Estimator"); st.caption("AI Applications • Regression Project"); st.divider(); page=st.radio("Navigate",["🏠 Home","🔮 Prediction","📊 Model Performance","🧠 How It Works","📚 About Project"],label_visibility="collapsed"); st.divider(); st.caption("Model: Random Forest Regressor"); st.caption(f"Test MAE: {RESULTS['Random Forest Regressor'][0]:.2f}"); st.caption(f"Test RMSE: {RESULTS['Random Forest Regressor'][1]:.2f}")

if page=="🏠 Home":
 st.markdown('<div class="hero"><h1>💳 Credit Card Fraud Financial Loss Prediction</h1><p>Estimate expected financial exposure associated with a potentially fraudulent transaction using regression.</p></div>',unsafe_allow_html=True); st.subheader("Project at a glance"); a,b,c,d=st.columns(4); a.metric("Transactions","1,296,675"); b.metric("Fraudulent","7,506"); c.metric("Problem Type","Regression"); d.metric("Selected Model","Random Forest"); st.divider(); st.subheader("What this application does"); x,y,z,w=st.columns(4); x.markdown("### 1️⃣ Enter\nTransaction amount and transaction details."); y.markdown("### 2️⃣ Prepare\nLocations and time are converted into model features."); z.markdown("### 3️⃣ Predict\nThe regression model estimates expected financial exposure."); w.markdown("### 4️⃣ Evaluate\nMAE and RMSE show test-set performance."); st.info(f"The source dataset contains transaction amounts from ${AMT_MIN:,.2f} to ${AMT_MAX:,.2f}. Predictions outside this range are not supported because they are outside the model's training distribution.")

elif page=="🔮 Prediction":
 st.title("🔮 Financial Loss Estimation"); st.write("Enter a transaction within the range represented in the training data."); st.markdown(f'<span class="badge">Regression</span><span class="badge">Random Forest</span><span class="badge">Amount range ${AMT_MIN:,.2f}–${AMT_MAX:,.2f}</span>',unsafe_allow_html=True); st.subheader("💳 Transaction details"); c1,c2,c3=st.columns(3)
 with c1:
  amount=st.number_input("Transaction amount ($)",min_value=float(AMT_MIN),max_value=float(AMT_MAX),value=100.0,step=10.0,help=f"The dataset contains amounts from ${AMT_MIN:,.2f} to ${AMT_MAX:,.2f}."); category=st.selectbox("Transaction category",categories); gender=st.selectbox("Gender",["F","M"])
 with c2:
  city_pop=st.number_input("Customer city population",min_value=0,value=50000,step=1000); job=st.text_input("Job",value="Student"); transaction_date=st.date_input("Transaction date")
 with c3:
  transaction_time=st.time_input("Transaction time"); st.caption("Date/time are converted into hour, day, month and weekday features.")
 st.subheader("📍 Location"); left,right=st.columns(2)
 with left:
  st.markdown("**Customer location**"); csn=st.selectbox("Customer state",display_names,key="customer_state"); cs=display_to_code[csn]; ccities=locations.loc[locations.state==cs,"city"].drop_duplicates().sort_values().tolist(); cc=st.selectbox("Customer city",ccities,key="customer_city"); cr=locations[(locations.state==cs)&(locations.city==cc)].iloc[0]
 with right:
  st.markdown("**Merchant location**"); msn=st.selectbox("Merchant state",display_names,key="merchant_state"); ms=display_to_code[msn]; mcities=locations.loc[locations.state==ms,"city"].drop_duplicates().sort_values().tolist(); mc=st.selectbox("Merchant city",mcities,key="merchant_city"); mr=locations[(locations.state==ms)&(locations.city==mc)].iloc[0]
 st.caption("Full state names are shown in the interface; the model receives the original state codes and coordinates.")
 st.divider()
 if st.button("🔮 Estimate Financial Loss",type="primary",use_container_width=True):
  dt=datetime.combine(transaction_date,transaction_time); inp=pd.DataFrame([{"amt":amount,"category":category,"gender":gender,"city":cc,"state":cs,"job":job,"lat":float(cr.lat),"long":float(cr.long),"city_pop":city_pop,"merch_lat":float(mr.lat),"merch_long":float(mr.long),"hour":dt.hour,"day":dt.day,"month":dt.month,"day_of_week":dt.weekday()}]); pred=max(0.0,float(model.predict(inp)[0])); st.markdown(f'<div class="result-card"><div class="small-note">Estimated Financial Loss / Exposure</div><div class="amount">${pred:,.2f}</div><div class="small-note">Random Forest Regressor</div></div>',unsafe_allow_html=True); st.success("Prediction completed successfully."); st.caption("This is an estimated expected-loss value, not a confirmed bank loss and not a guarantee that the transaction is fraudulent.");
  with st.expander("View model inputs"): st.dataframe(inp,use_container_width=True)

elif page=="📊 Model Performance":
 st.title("📊 Model Performance"); st.write("Results from the held-out test set used during the final training run."); results=pd.DataFrame({"Model":["Linear Regression","Random Forest Regressor"],"MAE":[RESULTS["Linear Regression"][0],RESULTS["Random Forest Regressor"][0]],"RMSE":[RESULTS["Linear Regression"][1],RESULTS["Random Forest Regressor"][1]]}); st.dataframe(results,hide_index=True,use_container_width=True); st.bar_chart(results.set_index("Model")); st.subheader("What do these metrics mean?"); st.markdown("- **MAE:** average absolute prediction error.\n- **RMSE:** error metric that gives more weight to larger errors.\n- Lower values mean smaller errors on the held-out test data."); st.info("The regression target is an expected financial-loss estimate derived during training from transaction amount and independently estimated fraud risk. It is not a confirmed bank-loss field.")

elif page=="🧠 How It Works":
 st.title("🧠 How It Works"); steps=[("1. Dataset","Kaggle credit-card transactions are loaded and prepared."),("2. Risk estimation","An independent fraud-risk model estimates the probability of fraud during training."),("3. Expected-loss target","Transaction amount × estimated fraud probability creates a continuous expected-loss target."),("4. Feature engineering","Date/time become hour, day, month and weekday; categorical values are encoded."),("5. Regression","Linear Regression and Random Forest Regressor learn to estimate expected financial loss."),("6. Evaluation","MAE and RMSE are calculated on held-out data."),("7. Prediction","The selected Random Forest estimates expected financial exposure for a new transaction.")];
 for title,desc in steps: st.markdown(f'<div class="card"><h3>{title}</h3><p>{desc}</p></div>',unsafe_allow_html=True); st.write("")
 st.warning("Important: the training dataset contains amounts only up to $28,948.90. A value such as $2,998,000 is far outside the data distribution, so the app deliberately prevents unsupported predictions at that scale.")

elif page=="📚 About Project":
 st.title("📚 About Project"); st.subheader("Objective"); st.write("Estimate expected financial loss/exposure associated with potentially fraudulent credit-card transactions using regression."); st.subheader("Dataset"); st.write("Kaggle credit-card transaction dataset with transaction, customer, merchant, location and fraud-label information."); st.subheader("Models"); st.write("Linear Regression and Random Forest Regressor."); st.subheader("Final test results"); st.write(f"Linear Regression — MAE {RESULTS['Linear Regression'][0]:.2f}, RMSE {RESULTS['Linear Regression'][1]:.2f}. Random Forest — MAE {RESULTS['Random Forest Regressor'][0]:.2f}, RMSE {RESULTS['Random Forest Regressor'][1]:.2f}."); st.subheader("Important limitation"); st.write("The source dataset does not provide a separately verified post-fraud bank-loss amount. The project therefore estimates expected financial exposure using transaction amount and independently estimated fraud risk. It should not be presented as confirmed financial loss."); st.subheader("Future scope"); st.markdown("- Use a dataset containing confirmed financial-loss/recovery amounts.\n- Add stronger fraud-risk features.\n- Compare additional regression algorithms.\n- Deploy the application for demonstration and monitoring.")
